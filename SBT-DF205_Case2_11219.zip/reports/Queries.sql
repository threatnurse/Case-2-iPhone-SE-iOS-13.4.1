-- ============================================================
-- SBT-DF205-C2 iOS Forensics Queries
-- ============================================================

-- TASK 2: Accounts
-- Target Database: Accounts3.sqlite
-- Purpose: Identify the iCloud account associated with the device.
SELECT Z_PK, ZUSERNAME, ZACCOUNTDESCRIPTION FROM ZACCOUNT;

-- TASK 3: Messages
-- Target Database: sms.db
-- Purpose: Reconstruct the conversation with joshua.hickman1@me.com.
SELECT m.ROWID, m.text, m.is_from_me, m.service, m.date, h.id AS sender_number
FROM message m
JOIN chat_message_join cmj ON m.ROWID = cmj.message_id
JOIN chat c ON cmj.chat_id = c.ROWID
LEFT JOIN handle h ON m.handle_id = h.ROWID
WHERE c.chat_identifier = 'joshua.hickman1@me.com'
ORDER BY m.date ASC;

-- TASK 3: Attachment Tracing
-- Target Database: sms.db
-- Purpose: Find the attachment record for message ROWID 38.
SELECT m.ROWID, a.ROWID, a.filename, a.mime_type, a.total_bytes
FROM message m
JOIN message_attachment_join maj ON m.ROWID = maj.message_id
JOIN attachment a ON maj.attachment_id = a.ROWID
WHERE m.ROWID = 38;

-- TASK 3: Contacts
-- Target Database: AddressBook.sqlitedb
-- Purpose: List all stored contacts and their phone numbers/emails.
SELECT ROWID, First, Last, Organization FROM ABPerson;
SELECT record_id, property, value FROM ABMultiValue;

-- TASK 3: Call History
-- Target Database: CallHistory.storedata
-- Purpose: List the 5 most recent calls with direction and duration.
SELECT ROWID, ZADDRESS, ZCALLTYPE, ZORIGINATED, ZANSWERED, ZDURATION, ZDATE
FROM ZCALLRECORD ORDER BY ZDATE DESC LIMIT 5;

-- TASK 4: Safari History
-- Target Database: History.db
-- Purpose: Export the 10 most recent web visits.
SELECT hv.id, hi.url, hv.title, hv.visit_time
FROM history_visits hv
JOIN history_items hi ON hv.history_item = hi.id
ORDER BY hv.visit_time DESC LIMIT 10;

-- TASK 4: Calendar
-- Target Database: Calendar.sqlitedb
-- Purpose: Count calendar events and list sample entries.
SELECT COUNT(*) AS Total_Events FROM CalendarItem;
SELECT ROWID, summary, start_date, end_date FROM CalendarItem ORDER BY start_date DESC LIMIT 5;

-- TASK 5: Photos
-- Target Database: Photos.sqlite
-- Purpose: Extract media records with filenames and timestamps.
SELECT Z_PK, ZFILENAME, ZDIRECTORY, ZDATECREATED, ZADDEDDATE, ZLATITUDE, ZLONGITUDE
FROM ZGENERICASSET LIMIT 5;

-- TASK 5: Photo Origin
-- Target Database: Photos.sqlite
-- Purpose: Determine if photos were imported by a 3rd party app.
SELECT Z_PK, ZORIGINALFILENAME, ZIMPORTEDBY, ZCREATORBUNDLEID, ZEXIFTIMESTAMPSTRING
FROM ZADDITIONALASSETATTRIBUTES WHERE Z_PK IN (1,2,3,4,5);

-- TASK 6: KnowledgeC Application Focus
-- Target Database: knowledgeC.db
-- Purpose: Extract records of which app was in focus.
SELECT Z_PK, ZSTREAMNAME, ZVALUESTRING, ZSTARTDATE, ZENDDATE
FROM ZOBJECT WHERE ZSTREAMNAME = '/app/inFocus'
ORDER BY ZSTARTDATE DESC LIMIT 5;

-- TASK 6: KnowledgeC Device Lock State
-- Target Database: knowledgeC.db
-- Purpose: Extract device lock/unlock intervals.
SELECT Z_PK, ZSTREAMNAME, ZVALUEINTEGER, ZSTARTDATE, ZENDDATE
FROM ZOBJECT WHERE ZSTREAMNAME = '/device/isLocked'
ORDER BY ZSTARTDATE DESC LIMIT 5;

-- TASK 7: Health Activity
-- Target Database: healthdb_secure.sqlite
-- Purpose: Extract daily step counts and distance.
SELECT datetime(cache_index+978307200,'unixepoch','utc') AS date, steps, walk_distance, energy_burned
FROM activity_caches ORDER BY cache_index DESC LIMIT 2;

-- TASK 7: Cell Location
-- Target Database: cache_encryptedB.db
-- Purpose: Extract raw cell tower/Wi-Fi reference locations.
SELECT Timestamp, Latitude, Longitude FROM LteCellLocation ORDER BY Timestamp DESC LIMIT 3;

-- TASK 7: Frequent Locations (Learned Visits)
-- Target Database: Local.sqlite
-- Purpose: Extract learned visits with entry and exit times.
SELECT Z_PK, datetime(ZCREATIONDATE+978307200,'unixepoch','utc') AS creation_time,
       datetime(ZENTRYDATE+978307200,'unixepoch','utc') AS entry_time,
       datetime(ZEXITDATE+978307200,'unixepoch','utc') AS exit_time,
       ZLOCATIONLATITUDE AS Latitude, ZLOCATIONLONGITUDE AS Longitude
FROM ZRTLEARNEDLOCATIONOFINTERESTVISITMO ORDER BY ZENTRYDATE DESC LIMIT 3;
